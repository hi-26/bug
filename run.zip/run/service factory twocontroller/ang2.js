!function(){
    "use strict";
   var obj=[{'name':'Antony'}];
    angular.module("myApp",[])
    .controller("lol",conf)
    .service('f',func)
    .filter('shit',function(){
        return function(x){
            var t=x+' dix on fire'
            return t

        }
    })
    
    function func()
    {
        var factory=this
        factory.add=function(name){
            var item={'name':name};
            obj.push(item);
        
        }
        factory.rem=function(idx){
            obj.splice(idx,1);
        }
        
    }

    function conf($scope,f)
    {
        $scope.obj=obj;
        $scope.an=function(){
            $scope.result=f.add($scope.name);

        }
        $scope.r=function(ind){
            $scope.result=f.rem(ind);
        }
    };
}();