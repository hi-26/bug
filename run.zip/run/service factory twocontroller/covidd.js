!function(){
"use strict";
var covidcase_details=[
{State:"TamilNadu",Newcase:300,Recoveredcase:200,Totaldeath:50},
{State:"Karnataka",Newcase:2000,Recoveredcase:1000,Totaldeath:104},
{State:"Andra Pradhesh",Newcase:750,Recoveredcase:130,Totaldeath:95},
{State:"Kerala",Newcase:3500,Recoveredcase:1500,Totaldeath:90},
{State:"Maharastra",Newcase:2500,Recoveredcase:1200,Totaldeath:80},
];
var vaccine_details=[
{State:"TamilNadu",Total_vaccinated:10387,Vaccine_name:"covidsheild,covaxin"},
{State:"Karnataka",Total_vaccinated:8050,Vaccine_name:"covidsheild,covaxin"},
{State:"Andra Pradhesh",Total_vaccinated:7508,Vaccine_name:"covidsheild,covaxin"},
{State:"Kerala",Total_vaccinated:6987,Vaccine_name:"covidsheild,covaxin"},
{State:"Maharastra",Total_vaccinated:7327,Vaccine_name:"covidsheild,covaxin"},
];
angular.module('myApp',[])
.controller('firstController',firstController)
.controller('secondController',secondController);
firstController.$inject=['$scope'];
secondController.$inject['$scope'];
function firstController($scope){
$scope.covidcase_details=covidcase_details;
}
function secondController($scope){
$scope.vaccine_details=vaccine_details;
}
}();