<?php

	include('connection.php');

	if(isset($_POST['login'])){
		$name = htmlentities(mysqli_real_escape_string($con,$_POST['name']));
		$pass = htmlentities(mysqli_real_escape_string($con,$_POST['pass']));
		
		$select = "select * from users where username='$name' AND password='$pass'";
		$query  = mysqli_query($con,$select);
		$check = mysqli_num_rows($query);

		if($check==1){
			echo "<script>window.alert('Successfully Logged in !!!')</script>";
			echo "<script>window.open('welcome.php','_self')</script>";
		}
		else{
			echo "<script>window.alert('User doesn't exist !!!')</script>";
		}
		
	}
	if(isset($_POST['register'])){
		$name1 = htmlentities(mysqli_real_escape_string($con,$_POST['rname']));
		$pass1 = htmlentities(mysqli_real_escape_string($con,$_POST['rpass']));
		$email1 = htmlentities(mysqli_real_escape_string($con,$_POST['remail']));
		$phoneno1 = htmlentities(mysqli_real_escape_string($con,$_POST['rphone']));
		$insert = "insert into users (username,password,email,phoneno) values('$name1','$pass1','$email1','$phoneno1')";
		$query=mysqli_query($con,$insert);
		if($query){
			echo "<script>window.alert('success')</script>";
		}
	}
	if(isset($_POST['upd'])){
		$name2 = htmlentities(mysqli_real_escape_string($con,$_POST['update1']));
		$name3 = htmlentities(mysqli_real_escape_string($con,$_POST['update2']));
		$update = "update users set username='$name3' where username='$name2'";
		$query=mysqli_query($con,$update);
		if($query){
			echo "<script>window.alert('success')</script>";
		}
	}
	if(isset($_POST['delet'])){
		$name4 = htmlentities(mysqli_real_escape_string($con,$_POST['del']));
		$delete = "delete from users where username='$name4'";
		$query=mysqli_query($con,$delete);
		if($query){
			echo "<script>window.alert('success')</script>";
		}
	}
?>