<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
</head>
<body>
	<center>
	<h2>Login</h2>
	<form method='POST' action='loginUser.php'>
		<p>Enter your name</p>
		<input type="text" name='name' required>
		<p>Enter your password</p>
		<input type="text" name='pass' required><br><br>
		<input type="submit" name="login" value='Login'>
	</form>
	<br><hr><br>
<h2>Register</h2>
	<form method='POST' action='loginUser.php'>
		<p>Enter your name</p>
		<input type="text" name='rname'>
		<p>Enter your email</p>
		<input type="text" name='remail' required>
		<p>Enter your phone number</p>
		<input type="text" name='rphone' required>
		<p>Enter your password</p>
		<input type="text" name='rpass' required><br><br>
		<!-- <input type="submit" name="register" value='Register'> -->
		<button name="register">Register</button>
		<p>update</p>
		<input name="update1" placeholder="search">
		<input name="update2" placeholder="replace">
		<button name="upd">update</button>
		<p>delete</p>
		<input type="text" name='del'>
		<button name="delet">delete</button>
	</form>
	</center>
</body>

<?php include('loginUser.php'); ?>

</html>