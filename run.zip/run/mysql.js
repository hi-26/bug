var mysql = require('mysql');
var con = mysql.createConnection({
	host:"localhost",
	user:"root",
	database:"sidd",
	password:""
});
con.connect(function(err){
	if(err) throw err;
	console.log("Connected!");
	var sql = "CREATE TABLE studentsss(name VARCHAR(255),address VARCHAR(255))";
	con.query(sql, function(err,result){
		if(err) throw err;
		console.log("Table created!");
	});	
});
"CREATE DATABASE mydb"
"INSERT INTO customers (name, address) VALUES ('Company Inc', 'Highway 37')";
"SELECT * FROM customers"
"DELETE FROM customers WHERE address = 'Mountain 21'";
"UPDATE customers SET address = 'Canyon 123' WHERE address = 'Valley 345'";
"SELECT users.name AS user, products.name AS favorite FROM users JOIN products ON users.favorite_product = products.id";