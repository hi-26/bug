var users=[];
var app = angular.module('myapp',[]);
app.controller('mycontroller',function($scope,$http){
	$http.get('/users').then(function(data){
		$scope.users = data.data;
	});
});
