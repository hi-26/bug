const express = require('express');
const bp = require('body-parser');
const sql = require('mysql');

const app = express();
app.use(bp.json());
app.use(bp.urlencoded({extended:false}));

app.use(express.static('script'));

const db = sql.createConnection({
	host:'localhost',
	user:'root',
	password:'',
	database:'newfolder',
	port:3306
});

db.connect((err)=>{
	if(err) throw err;
	console.log('Db connected');
});

app.get('/',(req,res)=>{
	res.sendFile(`${__dirname}/new.html`);
})

app.get('/users',(req,res)=>{
	let qr = `SELECT * FROM users`;
	db.query(qr,(err,result)=>{
		if (err) throw err;
		console.log(result);
		res.send(result);
	});
});


app.post('/insert',(req,res)=>{

	let name = req.body.user_name;

	let qr = `INSERT INTO users (name) VALUES('${name}')`;

	db.query(qr,(err,result)=>{
		if (err) throw err;
	});
	res.redirect('/');

})


app.listen(7000,(err)=>{
	if (err) throw err;
	console.log('Server listenting on 7000');
});