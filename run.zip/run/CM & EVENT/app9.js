const Info = require('./app8');
const in1 = new Info.Information1();
console.log(Info);
5 console.log(ini);
ini.info1 ('Welcome');
in1.info2('TCE', 'WT');
